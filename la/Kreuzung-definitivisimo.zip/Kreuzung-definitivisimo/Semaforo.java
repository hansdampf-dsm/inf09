
/**
 * Beschreiben Sie hier die Klasse Semaforo.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Semaforo
{
    // Instanzvariablen - ersetzen Sie das folgende Beispiel mit Ihren Variablen
    LAMPE lampeOben;
    LAMPE lampeMittel;
    LAMPE lampeUnten;
   
    String Semaforo = "rot";
    
    /**
     * Konstruktor f�r Objekte der Klasse Semaforo
     */
    public Semaforo(int x, int y)
    {
        // Instanzvariable initialisieren
        lampeOben = new LAMPE();
        lampeMittel = new LAMPE();
        lampeUnten = new LAMPE();
        
        lampeOben.PositionSetzen(x+1,y+1);
        lampeMittel.PositionSetzen(x+1,y+2);
        lampeUnten.PositionSetzen(x+1,y+3);
        lampeOben.FarbeSetzen("gruen");
        lampeMittel.FarbeSetzen("gelb");
        lampeUnten.FarbeSetzen("rot");
   }
   public void gruenSetzen()
   {
       lampeOben.FarbeSetzen("gruen");
       lampeMittel.FarbeSetzen("schwarz");
       lampeUnten.FarbeSetzen("schwarz");
   }public void gelbSetzen()
   {
       lampeOben.FarbeSetzen("schwarz");
       lampeMittel.FarbeSetzen("gelb");
       lampeUnten.FarbeSetzen("schwarz");
   }
   public void rotSetzen()
   {
       lampeOben.FarbeSetzen("schwarz");
       lampeMittel.FarbeSetzen("schwarz");
       lampeUnten.FarbeSetzen("rot");
   }    
   public void rotgelbSetzen()
   {
       lampeOben.FarbeSetzen("schwarz");
       lampeMittel.FarbeSetzen("gelb");
       lampeUnten.FarbeSetzen("rot");
   }
   public void FarbeAndern()
   {
       if (Semaforo=="rot")
       {
        rotSetzen();
        Semaforo = "rotgelb";
       }
       else if (Semaforo=="rotgelb")
       {
        rotgelbSetzen();
        Semaforo = "gruen";
       }  
        else if (Semaforo=="gruen")
       {
        gruenSetzen();
        Semaforo = "gelb";
       }
        else if (Semaforo=="gelb")
       {
        gelbSetzen();
        Semaforo = "rot";
       }
   }
   public void AusrichtungSetzen(String Ausrichtung)
   {
       if (Ausrichtung=="nord")
       {
           lampeOben.PositionSetzen(-4,-4);
           lampeMittel.PositionSetzen(-4,-5);
           lampeUnten.PositionSetzen(-4,-6);
       }
       else if (Ausrichtung=="sud")
       {
           lampeOben.PositionSetzen(3,3);
           lampeMittel.PositionSetzen(3,4);
           lampeUnten.PositionSetzen(3,5);
       }
       else if (Ausrichtung=="west")
       {
           lampeOben.PositionSetzen(-4,3);
           lampeMittel.PositionSetzen(-5,3);
           lampeUnten.PositionSetzen(-6,3);
       }
       else if (Ausrichtung=="ost")
       {
           lampeOben.PositionSetzen(3,-4);
           lampeMittel.PositionSetzen(4,-4);
           lampeUnten.PositionSetzen(5,-4);
       }
   }
}