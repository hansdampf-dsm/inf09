
public class FusgangerAmpel
{
    LAMPE lampeArriba;
    LAMPE lampeAbajo;
    String FusgangerAmpel = "rot";
    public FusgangerAmpel(int x, int y)
    {
       lampeArriba = new LAMPE();
       lampeAbajo = new LAMPE();
       
       lampeArriba.PositionSetzen(x+1,y+1);
       lampeAbajo.PositionSetzen(x+1,y+1);
       lampeArriba.FarbeSetzen("gruen");
       lampeAbajo.FarbeSetzen("rot");
    }
    public void GruenSetzen()
    {
        lampeArriba.FarbeSetzen("gruen");
        lampeAbajo.FarbeSetzen("schwarz");
    }
    public void RotSetzen()
    {
        lampeArriba.FarbeSetzen("schwarz");
        lampeAbajo.FarbeSetzen("rot");
    }
    public void FarbeAndern()
    {
       if (FusgangerAmpel=="rot")
       {
        RotSetzen();
        FusgangerAmpel = "gruen";
       }
        else if (FusgangerAmpel=="gruen")
       {
        GruenSetzen();
        FusgangerAmpel = "rot";
       }
    }
     public void AusrichtungSetzen(String Ausrichtung)
    {
       if (Ausrichtung=="nord")
       {
           lampeArriba.PositionSetzen(-4,-3);
           lampeAbajo.PositionSetzen(-5,-3);
       }
       else if (Ausrichtung=="sud")
       {
           lampeArriba.PositionSetzen(3,2);
           lampeAbajo.PositionSetzen(4,2);
       }
       else if (Ausrichtung=="west")
       {
           lampeArriba.PositionSetzen(-4,4);
           lampeAbajo.PositionSetzen(-4,3);
       }
       else if (Ausrichtung=="ost")
       {
           lampeArriba.PositionSetzen(3,-4);
           lampeAbajo.PositionSetzen(3,-5);
       }
    }
}
