
/**
 * Beschreiben Sie hier die Klasse Kreuzung.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Kreuzung
{
    // Instanzvariablen - ersetzen Sie das folgende Beispiel mit Ihren Variablen
    private int x;
    Semaforo ampelS;
    Semaforo ampelN;
    Semaforo ampelW;
    Semaforo ampelO;
    
    FusgangerAmpel semaforoS;
    FusgangerAmpel semaforoN;
    FusgangerAmpel semaforoW;
    FusgangerAmpel semaforoO;
    int weiterschalten;
    /**
     * Konstruktor f�r Objekte der Klasse Kreuzung
     */
    public Kreuzung()
    {
        // Instanzvariable initialisieren
        ampelS = new Semaforo(-5,5);
        ampelN = new Semaforo(2,-10);
        ampelW = new Semaforo(5,0);
        ampelO = new Semaforo(-5,-7);
        ampelS.AusrichtungSetzen("sud");
        ampelN.AusrichtungSetzen("nord");
        ampelW.AusrichtungSetzen("west");
        ampelO.AusrichtungSetzen("ost");
        weiterschalten = 1;
        ampelO.gruenSetzen();
        ampelW.gruenSetzen();
        ampelN.rotSetzen();
        ampelS.rotSetzen();
    }
    public void FarbeAndern()
    {
        if (weiterschalten==1)
        {
         ampelO.gelbSetzen();
         ampelW.gelbSetzen();
         weiterschalten=2;
        }
        else if (weiterschalten==2)
        {
         ampelO.rotSetzen();
         ampelW.rotSetzen();
         weiterschalten=3;
        }
        else if (weiterschalten==3)
        {
         ampelN.rotgelbSetzen();
         ampelS.rotgelbSetzen();
         weiterschalten=4;
        }
        else if (weiterschalten==4)
        {
         ampelN.gruenSetzen();
         ampelS.gruenSetzen();
         weiterschalten=5;
        }
        else if (weiterschalten==5)
        {
         ampelN.gelbSetzen();
         ampelS.gelbSetzen();
         weiterschalten=6;
        }
        else if (weiterschalten==6)
        {
         ampelN.rotSetzen();
         ampelS.rotSetzen();
         weiterschalten=7;
        }
        else if (weiterschalten==7)
        {
         ampelO.rotgelbSetzen();
         ampelW.rotgelbSetzen();
         weiterschalten=8;
        }
        else if (weiterschalten==8)
        {
         ampelO.gruenSetzen();
         ampelW.gruenSetzen();
         weiterschalten=1;
        }
    }
    public void Blinken()
    {
    for (int i = 0;
             i < 10000000;
             i++) {
            FarbeAndern();
            try
            {
                Thread.sleep(1000);
            }
            catch(InterruptedException e){};
        }
    }
}